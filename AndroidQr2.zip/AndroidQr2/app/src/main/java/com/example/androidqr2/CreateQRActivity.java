package com.example.androidqr2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.io.IOException;

public class CreateQRActivity extends AppCompatActivity {

    EditText inQRCode,in_printer_id;
    TextView buttonCreateQR,button_print;
    ImageView imageQR;
    PrintBluetooth printBT = new PrintBluetooth();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_qractivity);

        inQRCode = findViewById(R.id.in_qr_code);
        buttonCreateQR = findViewById(R.id.button_create);
        imageQR = findViewById(R.id.image_qr);
        in_printer_id = findViewById(R.id.in_printer_id);
        button_print = findViewById(R.id.button_print);

        buttonCreateQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!inQRCode.getText().toString().isEmpty()){
                    MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                    try {
                        BitMatrix bitMatrix = multiFormatWriter.encode(inQRCode.getText().toString(), BarcodeFormat.QR_CODE,300,300);
                        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                        Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                        imageQR.setImageBitmap(bitmap);
                    }catch(Exception e){e.printStackTrace();}
                }
            }
        });

        button_print.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //hna khasni nchf ta3 id printer
                PrintBluetooth.printer_id = in_printer_id.getText().toString();
                Bitmap qrBit = printQRCode(inQRCode.getText().toString());
                try {
                    printBT.findBT();
                    printBT.openBT();
                    printBT.printQrCode(qrBit);
                    printBT.closeBT();
                }catch(IOException ex){ex.printStackTrace();}
            }
        });
    }

    private Bitmap printQRCode(String textToQR){
        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
        try {
            //generate QrCode
            BitMatrix bitMatrix = multiFormatWriter.encode(textToQR, BarcodeFormat.QR_CODE, 300,300);
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
            return bitmap;
        }catch(WriterException e){
            e.printStackTrace();
            return null;
        }
    }
}